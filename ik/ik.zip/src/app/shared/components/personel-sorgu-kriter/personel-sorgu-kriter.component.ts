import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SorguKriter } from '../../models/personelSorguKriter';

@Component({
  selector: 'app-personel-sorgu-kriter',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './personel-sorgu-kriter.component.html',
  styleUrl: './personel-sorgu-kriter.component.scss'
})
export class PersonelSorguKriterComponent {
  sorguKriter = new SorguKriter("", "");
  @Output('sorgula') sorgulaEvent = new EventEmitter();

  sorgula() {
    this.sorgulaEvent.emit(this.sorguKriter);
  }
}
