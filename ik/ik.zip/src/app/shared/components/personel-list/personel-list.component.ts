import { Component } from '@angular/core';

@Component({
  selector: 'app-personel-list',
  standalone: true,
  imports: [],
  templateUrl: './personel-list.component.html',
  styleUrl: './personel-list.component.scss'
})
export class PersonelListComponent {

}
