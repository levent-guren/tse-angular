import { Personel } from './personel';

describe('Personel', () => {
  it('should create an instance', () => {
    expect(new Personel()).toBeTruthy();
  });
});
