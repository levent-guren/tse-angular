export class SorguKriter {
    constructor(
        public adi: string,
        public soyadi: string,
    ) { }
}