export const environment = {
    apiUrl: "http://sunucu.com:8080",
    development: false
};
