export const environment = {
    apiUrl: "http://localhost:8080",
    development: true
};
